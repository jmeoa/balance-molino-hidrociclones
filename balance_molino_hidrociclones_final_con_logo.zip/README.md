# Balance de Masas: Molino - Hidrociclones

App Streamlit para simulación y visualización de eficiencia del ciclón y consumo energético en un circuito de molienda.